package constructorEx;

public class ConstructorEx {

	
		// TODO Auto-generated method stub
	private String name;
	private int age;
	
		    // Default constructor
	public ConstructorEx() {
		this.name = "John Doe";
		this.age = 0;
	}
		    
		    // Parameterized constructor
	public ConstructorEx(String name, int age) {
		this.name = name;
		this.age = age;
	}
		    
		    // Copy constructor
	public ConstructorEx(ConstructorEx other) {
		this.name = other.name;
		this.age = other.age;
	}
		    
		    // Getter methods
	public String getName() {
		return this.name;
	}
		    
	public int getAge() {
		return this.age;
	}
	
	public static void main(String[] args) {
		        // Using the default constructor
		ConstructorEx john = new ConstructorEx();
		System.out.println("Name: " + john.getName() + ", Age: " + john.getAge());
		        
		        // Using the parameterized constructor
		ConstructorEx jane = new ConstructorEx("Jane Smith", 25);
		System.out.println("Name: " + jane.getName() + ", Age: " + jane.getAge());
		        
		        // Using the copy constructor
		ConstructorEx mary = new ConstructorEx(jane);
		System.out.println("Name: " + mary.getName() + ", Age: " + mary.getAge());
	}
		


}
