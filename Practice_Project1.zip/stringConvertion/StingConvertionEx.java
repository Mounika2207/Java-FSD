package stringConvertion;

public class StingConvertionEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Hello, world!";

        StringBuffer sb = new StringBuffer(str);

        StringBuilder sb2 = new StringBuilder(sb);

        System.out.println("String: " + str);
        System.out.println("StringBuffer: " + sb.toString());
        System.out.println("StringBuilder: " + sb2.toString());

	}

}
