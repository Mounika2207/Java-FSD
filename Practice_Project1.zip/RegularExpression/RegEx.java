package RegularExpression;

import java.util.regex.*;

public class RegEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String regex = "[a-z]+";
        String input = "hello world";

        Pattern pattern = Pattern.compile(regex);

        Matcher matcher = pattern.matcher(input);

        if (matcher.matches()) {
            System.out.println("Input matches the pattern!");
        } else {
            System.out.println("Input does not match the pattern.");
        }
		
	}

}
