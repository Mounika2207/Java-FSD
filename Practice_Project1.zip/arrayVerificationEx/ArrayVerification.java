package arrayVerificationEx;

public class ArrayVerification {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1, 2, 3, 4, 5};
	      
	      // print the array
	      System.out.print("Array elements: ");
	      for (int i = 0; i < arr.length; i++) {
	         System.out.print(arr[i] + " ");
	      }
	      System.out.println();
	      
	      // verify that the array contains a specific element
	      int searchElement = 3;
	      boolean found = false;
	      for (int i = 0; i < arr.length; i++) {
	         if (arr[i] == searchElement) {
	            found = true;
	            break;
	         }
	      }
	      if (found) {
	         System.out.println("Array contains element " + searchElement);
	      } else {
	         System.out.println("Array does not contain element " + searchElement);
	      }
	      
	      // verify that the array is sorted in ascending order
	      boolean sorted = true;
	      for (int i = 0; i < arr.length - 1; i++) {
	         if (arr[i] > arr[i+1]) {
	            sorted = false;
	            break;
	         }
	      }
	      if (sorted) {
	         System.out.println("Array is sorted in ascending order");
	      } else {
	         System.out.println("Array is not sorted in ascending order");
	      }

	}

}
