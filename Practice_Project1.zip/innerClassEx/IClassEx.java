package innerClassEx;

public class IClassEx {

	
		private int outerData;

	    public IClassEx(int data) {
	        this.outerData = data;
	    }

	    public void outerMethod() {
	        System.out.println("Outer method called");
	    }
	    public class InnerClass {
	        private int innerData;

	        public InnerClass(int data) {
	            this.innerData = data;
	        }
	        public void innerMethod() {
	            System.out.println("Inner method called");
	            System.out.println("Inner data: " + innerData);
	            System.out.println("Outer data: " + outerData);
	            outerMethod();
	        }
	    }
	    public static void main(String[] args) {
	        IClassEx outer = new IClassEx(10);
	        IClassEx.InnerClass inner = outer.new InnerClass(20);
	        inner.innerMethod();
	}

}
