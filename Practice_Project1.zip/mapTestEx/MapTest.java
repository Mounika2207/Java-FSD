package mapTestEx;

import java.util.HashMap;
import java.util.Map;

public class MapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, Integer> map = new HashMap<>();
        
        map.put("John", 25);
        map.put("Mary", 30);
        map.put("Bob", 40);
        System.out.println("The Elements of Hashmap are:");
        for(Map.Entry<String,Integer> m:map.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }
        assert map.size() == 3;
        
        assert map.containsKey("Mary");
        
        assert map.containsValue(40);
        
        int age = map.get("John");
        assert age == 25;
        
        map.remove("Bob");
        assert map.size() == 2;
        
        map.clear();
        assert map.isEmpty();
		
	}

}
